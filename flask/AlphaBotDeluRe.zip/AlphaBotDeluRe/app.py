from flask import Flask, render_template, request
#import alphaLib
app = Flask(__name__)
#alpha = alphaLib.AlphaBot()
@app.route("/", methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        action = request.form.get('action')
        # if action == 'right':
        #     alpha.right()
        # if action == 'left':
        #     alpha.left()
        # if action == 'forward':
        #     alpha.forward()
        # if action == 'backward':
        #     alpha.backward()
       # Qui puoi gestire l'azione ricevuta (ad esempio, inviare comandi all'AlphaBot)
        print(f"Azione ricevuta: {action}")
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')